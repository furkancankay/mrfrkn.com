const apiUrl = "https://64a6b892096b3f0fcc806e66.mockapi.io/Todo";
async function getPersonsData() {
  try {
    const response = await fetch(apiUrl, {
      method: "GET",
    });

    if (!response.ok) {
      throw new Error("HTTP hata kodu: " + response.status);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Hata:", error);
    throw error;
  }
}

async function putPersonData(personData) {
  await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(personData),
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('HTTP Hatası ' + response.status);
      }
      return response.json();
    })
}

async function signup() {
  const nickname = document.getElementById("nickname").value.trim();
  const email = document.getElementById("email").value.trim();
  const firstpassword = document.getElementById("first-password").value.trim();
  const secondpassword = document.getElementById("second-password").value.trim();

  people = await getPersonsData();

  let personStatus = 0;
  people.forEach(person => {
    if (nickname == person.name) {
      personStatus = 1;
    }
    else if (email == person.email) {
      personStatus = 2;
    }
    else if ((firstpassword != secondpassword) || (firstpassword == "")) {
      personStatus = 3;
    }
  });

  if (personStatus == 0) {
    let theNewMember = {
      "name": nickname,
      "email": email,
      "password": firstpassword,
      "tasks": []
    }
    putPersonData(theNewMember);
    document.getElementById("nickname").value = "";
    document.getElementById("email").value = "";
    document.getElementById("first-password").value = "";
    document.getElementById("second-password").value = "";
    window.location.href = "todologin.html";
  }
  else if (personStatus == 1) {
    alert("This username already exist.");
  }
  else if (personStatus == 2) {
    alert("This email already exist.");
  }
  else if (personStatus == 3) {
    alert("Make sure your password.");
  }

}
