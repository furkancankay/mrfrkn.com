


// I am trying something for what i am
if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
	aboutme = document.getElementById("ima");
	aboutme.innerHTML = "<b>WHO AM I</b>";
}
else {
	const dynamicText = document.querySelector("#ima span");
	const words = [" Computer Engineer", " Problem Destroyer!", " IoT Engineer", " Novice Guitarist ^^", " Farmer", " Philosopher", " Economist", " Automation Engineer"];

	// Variables to track the position and deletion status of the word
	let wordIndex = 0;
	let charIndex = 0;
	let isDeleting = false;

	const typeEffect = () => {
		const currentWord = words[wordIndex];
		const currentChar = currentWord.substring(0, charIndex);
		dynamicText.textContent = currentChar;
		dynamicText.classList.add("stop-blinking");

		if (!isDeleting && charIndex < currentWord.length) {
			// If condition is true, type the next character
			charIndex++;
			setTimeout(typeEffect, 100);
		} else if (isDeleting && charIndex > 0) {
			// If condition is true, remove the previous character
			charIndex--;
			setTimeout(typeEffect, 50);
		} else {
			// If word is deleted then switch to the next word
			isDeleting = !isDeleting;
			dynamicText.classList.remove("stop-blinking");
			wordIndex = !isDeleting ? (wordIndex + 1) % words.length : wordIndex;
			setTimeout(typeEffect, 1200);
		}
	}
	typeEffect();
}





/*
	Stellar by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

	var	$window = $(window),
		$body = $('body'),
		$main = $('#main');

	// Breakpoints.
		breakpoints({
			xlarge:   [ '1281px',  '1680px' ],
			large:    [ '981px',   '1280px' ],
			medium:   [ '737px',   '980px'  ],
			small:    [ '481px',   '736px'  ],
			xsmall:   [ '361px',   '480px'  ],
			xxsmall:  [ null,      '360px'  ]
		});

	// Play initial animations on page load.
		$window.on('load', function() {
			window.setTimeout(function() {
				$body.removeClass('is-preload');
			}, 100);
		});

	// Nav.
		var $nav = $('#nav');

		if ($nav.length > 0) {

			// Shrink effect.
				$main
					.scrollex({
						mode: 'top',
						enter: function() {
							$nav.addClass('alt');
						},
						leave: function() {
							$nav.removeClass('alt');
						},
					});

			// Links.
				var $nav_a = $nav.find('a');

				$nav_a
					.scrolly({
						speed: 1000,
						offset: function() { return $nav.height(); }
					})
					.on('click', function() {

						var $this = $(this);

						// External link? Bail.
							if ($this.attr('href').charAt(0) != '#')
								return;

						// Deactivate all links.
							$nav_a
								.removeClass('active')
								.removeClass('active-locked');

						// Activate link *and* lock it (so Scrollex doesn't try to activate other links as we're scrolling to this one's section).
							$this
								.addClass('active')
								.addClass('active-locked');

					})
					.each(function() {

						var	$this = $(this),
							id = $this.attr('href'),
							$section = $(id);

						// No section for this link? Bail.
							if ($section.length < 1)
								return;

						// Scrollex.
							$section.scrollex({
								mode: 'middle',
								initialize: function() {

									// Deactivate section.
										if (browser.canUse('transition'))
											$section.addClass('inactive');

								},
								enter: function() {

									// Activate section.
										$section.removeClass('inactive');

									// No locked links? Deactivate all links and activate this section's one.
										if ($nav_a.filter('.active-locked').length == 0) {

											$nav_a.removeClass('active');
											$this.addClass('active');

										}

									// Otherwise, if this section's link is the one that's locked, unlock it.
										else if ($this.hasClass('active-locked'))
											$this.removeClass('active-locked');

								}
							});

					});

		}

	// Scrolly.
		$('.scrolly').scrolly({
			speed: 1000
		});

})(jQuery);