function login() {
    const password = document.getElementById("password").value.trim();
    const nickname = document.getElementById("nickname").value.trim();
    isThereLikeThatPerson(nickname,password);
    putVariablesToLocalStorage("17291729t", password, nickname);
}
const inputElement = document.getElementById("password");
const buttonElement = document.getElementById("login")
inputElement.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      buttonElement.click();
    }
  });

function getVariablesFromLocalStorage(type) {
    const localVariables = localStorage.getItem(type);
    if (localVariables) {
        return JSON.parse(localVariables);
    } else {
        return "Define it";
    }
}
function putVariablesToLocalStorage(listTitle, password, nickname) {
    let cookiesWithOutHash = getVariablesFromLocalStorage(listTitle);
    const nickpass = [password, nickname];
    if (cookiesWithOutHash == nickpass) {
        console.log("ok");
    }
    else {
        if (cookiesWithOutHash == "Define it") {
            localStorage.setItem(listTitle, JSON.stringify(nickpass));
        }
        else {
            if (cookiesWithOutHash[0] != nickpass[0]) {
                localStorage.setItem(listTitle, JSON.stringify(nickpass));
            }
        }
    }
}

async function isThereLikeThatPerson(nickname, password){
    apiUrl = "https://64a6b892096b3f0fcc806e66.mockapi.io/Todo"
    const response = await fetch(apiUrl, {
        method: "GET",
    });
    data = await response.json();
    let flag = 0;

    for (let i = 0; i < data.length; i++) {
        if((data[i].name == nickname) && (data[i].password == password)){
            console.log(data[i].name);
            flag = 1
            document.getElementById("nickname").value = "";
            document.getElementById("password").value = "";
            window.location.href = "todo.html";
        }
    }
    if(flag == 0){
        alert("Your informations are wrong.");
    }

}

function emailVerificationInfo(){
    document.getElementById("emailVerificationInfo").textContent = "Sorry about that but we will add this section. For now you can contact with fcnkaya0@gmail.com. He will change for you."
}

function createAnAccount(){
    window.location.href = "todosignup.html";
}