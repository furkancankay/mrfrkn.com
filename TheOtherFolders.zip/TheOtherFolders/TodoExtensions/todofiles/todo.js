document.getElementById("nickname").textContent = getVariablesFromLocalStorage("17291729t")[1];
let personid;
const apiUrl = "https://64a6b892096b3f0fcc806e66.mockapi.io/Todo";
async function getPersonsData() {
  try {
    const response = await fetch(apiUrl, {
      method: "GET",
    });

    if (!response.ok) {
      throw new Error("HTTP hata kodu: " + response.status);
    }

    const data = await response.json();
    let cnffjbeq = getVariablesFromLocalStorage("17291729t");
    for (let i = 0; i < data.length; i++) {
      if((data[i].password == cnffjbeq[0]) && (data[i].name == cnffjbeq[1])){
        personid = (data[i].id).toString();
      }
    }
    if(personid == null){
      console.log("There is not exist like that person.");
      document.getElementById("warning").textContent = "Dedem giriş yapmadan girmeye çalışman hiç hoş değil.";
    }
    tasksFromApi = data[personid-1].tasks;

    var tasks = getVariablesFromLocalStorage("tasks");
    tasks.splice(0, tasks.length);
    localStorage.setItem("tasks", JSON.stringify(tasks));

    tasksFromApi.forEach(task => {
      let tasks = getVariablesFromLocalStorage("tasks");
      tasks.push(task);
      localStorage.setItem("tasks", JSON.stringify(tasks));
    });

    renderTasks();
    return data;
  } catch (error) {
    console.error("Hata:", error);
    throw error; 
  }
}

async function main() {
  try {
    let a = await getPersonsData();
  } catch (error) {
    console.error("Ana işlev hatası:", error);
  }
}

main();




function getVariablesFromLocalStorage(type) {
  const localVariables = localStorage.getItem(type);
  if (localVariables) {
    return JSON.parse(localVariables);
  } else {
    return [];
  }
}

function renderTasks() {
  const tasksContainer = document.getElementById("taskTable");
  const completedContainer = document.getElementById("taskTable2");

  tasksContainer.innerHTML = "";
  completedContainer.innerHTML = "";

  const tasks = getVariablesFromLocalStorage("tasks");
  comletedtasksflag = 0;
  todotasksflag = 0;
  tasks.forEach((task) => {
    if (task.startsWith("<s>")) {
      comletedtasksflag = 1;
    } else {
      todotasksflag = 1;
    }
  });
  if(todotasksflag == 0){
    document.getElementById("completedSentence").textContent = "Hepsini halletmişsin valla dedem, helal olsun.";
  }
  else{
    document.getElementById("completedSentence").textContent = "";
  }

  if(comletedtasksflag == 1){
    document.getElementById("completedHeader").textContent = "Tokatlananlar"
  }
  else{
    document.getElementById("completedHeader").textContent = "";
  }
    tasks.forEach((task, index) => {
    const row = document.createElement("tr");

    const taskData = document.createElement("td");
    taskData.style.display = "flex";
    taskData.style.justifycontent = "center";
    taskData.innerHTML = task;
    row.appendChild(taskData);

    const okeyButton = document.createElement("button");
    const editdiv = document.createElement("div");
    editdiv.className = "editcontainer";
    okeyButton.id = "okeybtn";
    okeyButton.className = "material-icons";
    okeyButton.textContent = "done";
    okeyButton.addEventListener("click", () => {
      toggleTaskCompletion(index);
    });
    editdiv.appendChild(okeyButton);
    taskData.appendChild(editdiv);
    row.appendChild(taskData);

    const buttonElement = document.createElement("button");
    buttonElement.id = "removeButton";
    buttonElement.className = "material-icons";
    buttonElement.textContent = "delete";
    buttonElement.addEventListener("click", () => {
      removeTask(index);
    });

    editdiv.appendChild(buttonElement);
    taskData.appendChild(editdiv);
    row.appendChild(taskData);
    if (task.startsWith("<s>")) {
      completedContainer.appendChild(row);
    } else {
      tasksContainer.appendChild(row);
    }
  });
}

async function updateApi(){
  temp = []
  password = getVariablesFromLocalStorage("17291729t")[0];
  nickname = getVariablesFromLocalStorage("17291729t")[1];
  localtasks = getVariablesFromLocalStorage("tasks");
  localtasks.forEach(task => {
    temp.push(task);
  });
  let jsonVariables = {
    "name": nickname,
    "password": password,
    "tasks": temp
  }
  console.log(jsonVariables)
  await fetch(apiUrl+"/"+personid.toString(), {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(jsonVariables), 
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('HTTP Hatası ' + response.status);
      }
      return response.json(); 
    })
}

function addTask() {
  const inputElement = document.getElementById("textInput");
  const task = inputElement.value.trim();
  if (task !== "") {
    let tasks = getVariablesFromLocalStorage("tasks");
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    inputElement.value = "";
    
    updateApi();
  }
  renderTasks();
  
}

function removeTask(index) {
  const tasks = getVariablesFromLocalStorage("tasks");
  tasks.splice(index, 1);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  updateApi()
  renderTasks();
}

function toggleTaskCompletion(index) {
  const tasks = getVariablesFromLocalStorage("tasks");
  const task = tasks[index];
  if (task.startsWith("<s>")) {
    tasks[index] = task.substring(3, task.length - 4);
  } else {
    tasks[index] = `<s>${task}</s>`;
  }
  localStorage.setItem("tasks", JSON.stringify(tasks));
  updateApi()
  renderTasks();
}

function handleEnter(event) {
  if (event.keyCode === 13) {
    event.preventDefault();
    addTask();
  }
}

function logout(){
  localStorage.removeItem("17291729t");
}